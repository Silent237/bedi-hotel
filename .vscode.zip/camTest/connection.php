<?php
$host="localhost";
$user="root";
$password="mysql";
$databasename="webcam";

$con=  mysqli_connect($host,$user,$password,$databasename);

?>
