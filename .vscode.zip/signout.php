<?php
session_cache_limiter('nocache');
session_start();
include ("scripts/settings.php");

logout();

?>